<?php
session_start();
error_reporting(0);
include('includes/connection.php');
if($_SESSION['role'] == 'admin') {
    $vid=$_GET['viewid'];
    $Status='Approved';
    $sql="update tblbook set status='$Status' where id='$vid'";
    $data = mysqli_query($conn, $sql) or die(mysqli_error($conn));
   
  ?>
<!doctype html>
<html lang="en" class="no-focus"> <!--<![endif]-->
    <head>
        <title>Vivah Ceremony - view Booking Detail</title>

        <link rel="stylesheet" href="includes/js/plugins/datatables/dataTables.bootstrap4.min.css">

        <link rel="stylesheet" id="css-main" href="includes/css/codebase.min.css">

    </head>
    <body>
        
        <div id="wrapper">
           
           <?php include_once('includes/adminnav.php');?>

          <?php include_once('includes/adminheader.php');?>


            <!-- Main Container -->
            <main id="page-wrapper">
                <!-- Page Content -->
                <div class="container-fluid">
                    <h2 class="page-header">View Booking Details</h2>

                    
                           
                                    
                                <?php
                        $query = "SELECT * FROM tblbook where id=$vid";
                       $select_users = mysqli_query($conn, $query) or die(mysqli_error($conn));
                       if (mysqli_num_rows($select_users) > 0 ) {
                        while ($row = mysqli_fetch_array($select_users)) {
                           $id = $row['id'];
                           $name = $row['name'];
                           $number= $row['number'];
                           $email= $row['email'];
                           $type= $row['type'];
                           $city= $row['city'];
                           $date= $row['date'];
                           $payment= $row['payment'];
                           $status= $row['status'];
                           $book_date= $row['book_date'];

                           



                           
                       }
                       ?>
<table border="1" class="table table-bordered table-hover">
                                <tr>
                                    <th colspan="5" style="text-align: center;font-size: 20px;color: blue;">Booking Number: <?php echo $id;?>
                                        
                                    </th>
                                </tr>
                                            <tr>
    <th>Client Name</th>
    <td><?php  echo $name;?></td>
     <th>Mobile Number</th>
    <td><?php  echo $number;?></td>
  </tr>
  

  <tr>
    
   <th>Email</th>
    <td><?php  echo $email;?></td>
    <th>Wedding Type</th>
    <td><?php  echo $type;?></td>
  </tr>

   <tr>
    <th>City</th>
    <td><?php  echo $city;?></td>
    <th>Wedding Date</th>
    <td><?php  echo $date;?></td>
  </tr>

     <tr>
    <th>Advance Payment</th>
    <td><?php  echo $payment;?></td>
    <th class="font-w600">Status</th>
    <td><?php  echo $status;?></td>
  </tr>
 
  <tr>
    <th>Apply Date</th>
    <td><?php  echo $book_date;?></td>

  </tr>
  
  
 
<?php } ?>
  
    
    

  

    

</table> 

                              
                                  
                               
                       
                    <!-- END Dynamic Table Full Pagination -->

                    <!-- END Dynamic Table Simple -->
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->

           
        </div>
        <!-- END Page Container -->

        <script src="js/jquery.js"></script>

    
        <script src="js/bootstrap.min.js"></script>

    </body>
</html>
<?php } ?>