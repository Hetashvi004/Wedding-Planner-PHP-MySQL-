<?php
session_start();
error_reporting(0);

include('includes/connection.php');

  ?>

<!doctype html>
<html lang="en" class="no-focus"> <!--<![endif]-->
    <head>
        <title>Vivah Ceremony - Dashboard</title>

        <link rel="stylesheet" href="includes/js/plugins/datatables/dataTables.bootstrap4.min.css">

        <link rel="stylesheet" id="css-main" href="includes/css/codebase.min.css">

		<style type = "text/css">
			table td,tr,th
			{
			border:2px solid;
			border-collapse:collapse;
            width:40%;
            text-align:center;

			}
		</style>
	

    </head>
        
        <div id="wrapper">
           
           <?php include_once('includes/adminnav.php');?>

           <?php include_once('includes/adminheader.php');?>
           <h1>Dashboard...</h1>

           <table>
                        <tr>
                            <th bgcolor= #EDEDED>Total Users :</th>
                            <td bgcolor= #B8B8B8>
                            <?php
                
                                $query = "SELECT id FROM users ORDER BY id";  
                                $query_run = mysqli_query($conn, $query);
                                $row = mysqli_num_rows($query_run);
                                echo '<h4> Total Users: '.$row.'</h4>';
                            ?>
                            </td>
                        </tr>
                        
                            <hr>
                            <tr>
                            <th bgcolor= #B8B8B8>Total Contacts :</th>
                        <td bgcolor= #EDEDED>
                        <?php
            
                            $query = "SELECT ID FROM contact ORDER BY ID";  
                            $query_run = mysqli_query($conn, $query);
                            $row = mysqli_num_rows($query_run);
                            echo '<h4> Total Contacts: '.$row.'</h4>';
                        ?>
                        </td>
                        </tr>
                        
                            <hr>
                            <tr>
                        <th bgcolor= #EDEDED>Total Bookings :</th>
                        <td bgcolor= #B8B8B8>
                        <?php
            
                            $query = "SELECT id FROM tblbook ORDER BY id";  
                            $query_run = mysqli_query($conn, $query);
                            $row = mysqli_num_rows($query_run);
                            echo '<h4> Total Bookings: '.$row.'</h4>';
                        ?>
                        </td>
                    
                    
                    </div>


           <script src="js/jquery.js"></script>

    
        <script src="js/bootstrap.min.js"></script>

    </body>
</html>
