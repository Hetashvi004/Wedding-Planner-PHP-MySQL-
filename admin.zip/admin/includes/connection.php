<?php
$conn = mysqli_connect("localhost","root","","wedding_final" ) or die ("error" . mysqli_error($conn));
?>