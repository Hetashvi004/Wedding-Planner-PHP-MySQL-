<?php
session_start();
error_reporting(0);
include('includes/connection.php');

  ?>
<!doctype html>
<html lang="en" class="no-focus"> <!--<![endif]-->
    <head>
        <title>Wedding Ceremony - read Queries</title>

        <link rel="stylesheet" href="includes/js/plugins/datatables/dataTables.bootstrap4.min.css">

        <link rel="stylesheet" id="css-main" href="includes/css/codebase.min.css">

    </head>
    <body>
        
        <div id="wrapper">
           
           <?php include_once('includes/adminnav.php');?>

          <?php include_once('includes/adminheader.php');?>


            <!-- Main Container -->
            <main id="page-wrapper">
                <!-- Page Content -->
                <div class="container-fluid">
                    <h2 class="page-header">read Queries</h2>


                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th >#</th>
                                        
                                        <th>Name</th>
                                 
                                        <th>Email</th>
                                        <th>Send Message Date</th>
                                        <th style="width: 15%;">Action</th>
                                       </tr>
                                </thead>
                                <tbody>
                                    
                                <?php
                        $query = "SELECT * FROM contact where IsRead='1'";
                       $select_users = mysqli_query($conn, $query) or die(mysqli_error($conn));
                       if (mysqli_num_rows($select_users) > 0 ) {
                        while ($row = mysqli_fetch_array($select_users)) {
                           $ID = $row['ID'];
                           $Name = $row['Name'];
                           $Email = $row['Email'];
                           $EnquiryDate = $row['EnquiryDate'];
                           echo "<tr>";
                               echo "<td>$ID</td>";
                             echo "<td>$Name</a></td>";
                              echo "<td>$Email</td>";
                             echo "<td>$EnquiryDate</td>";
                             echo "<td ><a href='view-user-queries.php?viewid=$ID'><i class='fa fa-times fa-lg'></i>View</a></td>";
                          echo "</tr>";
                           }
                       }
                       ?>
                              
                                  
                                </tbody>
                                
                            </table>
                       
                    <!-- END Dynamic Table Full Pagination -->

                    <!-- END Dynamic Table Simple -->
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->

           <?php include_once('includes/footer.php');?>
        </div>
        <!-- END Page Container -->

        <script src="js/jquery.js"></script>

    
        <script src="js/bootstrap.min.js"></script>

    </body>
</html>
<?php  ?>