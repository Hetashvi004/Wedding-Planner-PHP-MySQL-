<?php
session_start();
error_reporting(0);
include('includes/connection.php');

  ?>
<!doctype html>
<html lang="en" class="no-focus"> <!--<![endif]-->
    <head>
        <title>Vivah Ceremony - All Booking</title>

        <link rel="stylesheet" href="includes/js/plugins/datatables/dataTables.bootstrap4.min.css">

        <link rel="stylesheet" id="css-main" href="includes/css/codebase.min.css">

    </head>
    <body>
        
        <div id="wrapper">
           
           <?php include_once('includes/adminnav.php');?>

           <?php include_once('includes/adminheader.php');?>


            <!-- Main Container -->
            <main id="page-wrapper">
                <!-- Page Content -->
                <div class="container-fluid">
                    <h2 class="page-header">All Booking</h2>


                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th >Booking Id</th>
                                        
                                        <th>Customer Name</th>
                                        <th>Phone Number</th>
                                        <th>Email</th>
                                        <th>Wedding Date</th>
                                        <th>Status</th>
                                        <th style="width: 15%;">Action</th>
                                       </tr>
                                </thead>
                                <tbody>
                                    
                                <?php
                        $query = "SELECT * FROM tblbook";
                       $select_users = mysqli_query($conn, $query) or die(mysqli_error($conn));
                       if (mysqli_num_rows($select_users) > 0 ) {
                        while ($row = mysqli_fetch_array($select_users)) {
                           $id = $row['id'];
                           $name = $row['name'];
                           $number = $row['number'];
                           $email = $row['email'];
                           $date = $row['date'];
                           $status = $row['status'];
                           echo "<tr>";
                               echo "<td>$id</td>";
                             echo "<td>$name</a></td>";
                             echo "<td>$number</a></td>";
                              echo "<td>$email</td>";
                             echo "<td>$date</td>";
                             echo "<td>$status</td>";
                             echo "<td><a href='view_booking_detail.php?viewid=$id'><i class='fa fa-times fa-lg'></i>View</a></td>";
                          echo "</tr>";
                           }
                       }
                       ?>
                              
                                  
                                </tbody>
                                
                            </table>
                       
                    <!-- END Dynamic Table Full Pagination -->

                    <!-- END Dynamic Table Simple -->
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->

           <?php include_once('includes/footer.php');?>
        </div>
        <!-- END Page Container -->

        <script src="js/jquery.js"></script>

    
        <script src="js/bootstrap.min.js"></script>

    </body>
</html>
<?php  ?>