<?php
session_start();
error_reporting(0);
include('includes/connection.php');
if($_SESSION['role'] == 'admin') {
    $vid=$_GET['viewid'];
    $isread=1;
    $sql="update contact set IsRead='$isread' where ID='$vid'";
    $data = mysqli_query($conn, $sql) or die(mysqli_error($conn));
   
  ?>
<!doctype html>
<html lang="en" class="no-focus"> <!--<![endif]-->
    <head>
        <title>Vivah Ceremony - view Queries</title>

        <link rel="stylesheet" href="includes/js/plugins/datatables/dataTables.bootstrap4.min.css">

        <link rel="stylesheet" id="css-main" href="includes/css/codebase.min.css">

    </head>
    <body>
        
        <div id="wrapper">
           
           <?php include_once('includes/adminnav.php');?>

          <?php include_once('includes/adminheader.php');?>


            <!-- Main Container -->
            <main id="page-wrapper">
                <!-- Page Content -->
                <div class="container-fluid">
                    <h2 class="page-header">View Queries</h2>

                    
                            <table class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Message</th>
                                        </tr>
    
                                </thead>
                                <tbody>
                                    
                                <?php
                        $query = "SELECT * FROM contact where ID=$vid";
                       $select_users = mysqli_query($conn, $query) or die(mysqli_error($conn));
                       if (mysqli_num_rows($select_users) > 0 ) {
                        while ($row = mysqli_fetch_array($select_users)) {
                           $Name = $row['Name'];
                           $Email = $row['Email'];
                           $Message= $row['Message'];
                           echo "<tr>";
                              echo "<td>$Name</a></td>";
                              echo "<td>$Email</td>";
                             echo "<td>$Message</td>";
                             echo "</tr>";
                           }
                       }
                       ?>


                              
                                  
                                </tbody>
                                
                            </table>
                       
                    <!-- END Dynamic Table Full Pagination -->

                    <!-- END Dynamic Table Simple -->
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->

           
        </div>
        <!-- END Page Container -->

        <script src="js/jquery.js"></script>

    
        <script src="js/bootstrap.min.js"></script>

    </body>
</html>
<?php }  ?>