<?php 
define("BASE_URL","");
define("API_KEY","rzp_test_5iEwoMgyRDrbhv");
define("API_SECRET","ZOQFj8dLP6my3qz96qQ2eUy3");
define("COMPANY_NAME","VIVAHCEREMONY");
define("COMPANY_LOGO_URL","image/logo.jpg");