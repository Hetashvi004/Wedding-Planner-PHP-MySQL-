-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2024 at 11:10 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wedding_final`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `ID` int(10) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Message` varchar(500) DEFAULT NULL,
  `EnquiryDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `IsRead` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`ID`, `Name`, `Email`, `Message`, `EnquiryDate`, `IsRead`) VALUES
(1, 'fenal', 'fenal@gmail.com', 'asfsf', '2024-03-08 16:24:31', 1),
(2, 'uri bhardiya', 'uri176@gmail.com', 'jshfsjkfhdsjkhfdsfks', '2024-03-08 16:27:37', 1),
(3, 'honey', 'honey@gmail.com', 'hii my name is honey , and i am devloper web smdnfdjghdkjfhdjkgdfghdjkghdfjkhgfdfkjhdjhddjkhgjhddjdhjdhjkhgfdkjhgjdkhfjdhgkjfdkddhjkgnvc cnfvbfjdvbdnqwvbe tyuiop[srftxcyuiopejl[wfskdvn,zm certyuiop', '2024-03-09 09:30:03', 1),
(4, 'sneha', 'sneha@gmail.com', 'aefwfwfwwr', '2024-03-09 11:44:27', 1),
(5, 'abs', 'sneha@gmail.com', 'sdfdhdsfdgfd', '2024-03-11 05:24:07', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblbook`
--

CREATE TABLE `tblbook` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `number` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `type` varchar(10) NOT NULL,
  `city` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `payment` int(20) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'No Processed Yet',
  `book_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='4';

--
-- Dumping data for table `tblbook`
--

INSERT INTO `tblbook` (`id`, `name`, `number`, `email`, `type`, `city`, `date`, `payment`, `status`, `book_date`) VALUES
(9, 'honey', '123456789', 'honey@gmail.com', 'premium', 'Kerala', '2024-03-30', 59000, 'Approved', '2024-03-12'),
(10, 'honey', '09737548515', 'honey@gmail.com', 'premium', 'Kerala', '2024-03-24', 59000, 'Approved', '2024-03-14'),
(11, 'uri bhardiya', '987896567', 'uri176@gmail.com', 'ultimate', 'Udaipur', '2024-03-30', 30000, 'Approved', '2024-03-14'),
(12, 'fenal', '09876543210', 'fenalpatel1910@gmail.com', 'simple', 'Goa', '2024-03-26', 30000, 'Approved', '2024-03-14'),
(13, 'Dhara', '7623941742', 'dhara@gmail.com', 'premium', 'Kerala', '2024-03-30', 50000, 'Approved', '2024-03-16'),
(14, 'Dhara', '7623941742', 'dhara@gmail.com', 'premium', 'Kerala', '2024-03-30', 20000, 'Approved', '2024-03-16'),
(15, 'Dhara', '7623941742', 'dhara@gmail.com', 'premium', 'Kerala', '2024-03-30', 12000, 'Approved', '2024-03-16'),
(16, 'uri bhardiya', '987896567', 'uri176@gmail.com', 'ultimate', 'Udaipur', '2024-03-31', 20000, 'No Processed Yet', '2024-03-16'),
(17, 'uri bhardiya', '987896567', 'uri176@gmail.com', 'ultimate', 'Udaipur', '2024-03-30', 0, 'No Processed Yet', '2024-03-16'),
(18, 'uri bhardiya', '987896567', 'uri176@gmail.com', 'ultimate', 'Udaipur', '2024-03-22', 0, 'No Processed Yet', '2024-03-16');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(200) NOT NULL,
  `username` text NOT NULL,
  `name` varchar(225) NOT NULL,
  `password` varchar(2000) NOT NULL,
  `email` varchar(2000) NOT NULL,
  `number` int(10) NOT NULL,
  `role` varchar(50) NOT NULL,
  `image` varchar(225) NOT NULL DEFAULT 'profile.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `name`, `password`, `email`, `number`, `role`, `image`) VALUES
(22, 'honey', 'Honey', '$2y$10$iWoHY9QYBUjZyMUrV.m/vODRrnY99oGsJcLFWjN5.i74d7apn8FkC', 'honey@gmail.com', 123456789, 'user', 'profile.jpg'),
(23, 'admin', 'Admin', '$2y$10$4thX/HEOadmjH0zQLWbOCuaAT71Z.IIrMjTU9Kcc2ZP.7sUlHkYg.', 'admin@mail.com', 2147483647, 'admin', '613090.jpg'),
(27, 'urii', 'Urii', '$2y$10$l7vpize.njba9uFCoMYz0ews8sD4wr2aQzOWzggCAiKAZJJ126asu', 'uri176@gmail.com', 987896567, 'user', 'profile.jpg'),
(29, 'dhara', 'Dhara', '$2y$10$3AUKLlqTQM1hjoo9k5sGd.G0EQ2aMEQadUnhxEEeHYpdy8olRr4bq', 'dhara@gmail.com', 2147483647, 'user', 'profile.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblbook`
--
ALTER TABLE `tblbook`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblbook`
--
ALTER TABLE `tblbook`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
